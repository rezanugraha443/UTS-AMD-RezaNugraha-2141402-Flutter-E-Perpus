import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax37bN (5:37)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xff000000),
        ),
        child: Stack(
          children: [
            Positioned(
              // rectangle182iL (14:37)
              left: 134*fem,
              top: 919*fem,
              child: Align(
                child: SizedBox(
                  width: 161*fem,
                  height: 5*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group18mN (5:45)
              left: 66*fem,
              top: 83*fem,
              child: Container(
                width: 305*fem,
                height: 98*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // eperpusU4Y (28:3)
                      left: 51*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 254*fem,
                          height: 60*fem,
                          child: Text(
                            'E-Perpus',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 50*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xff4d8dec),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // logoremovebgpreview1Mu2 (28:4)
                      left: 0*fem,
                      top: 4*fem,
                      child: Align(
                        child: SizedBox(
                          width: 50*fem,
                          height: 45*fem,
                          child: Image.asset(
                            'assets/page-1/images/logo-removebg-preview-1-GPJ.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // dagtaruntukmembacadanmenulisce (5:47)
                      left: 0.5*fem,
                      top: 59*fem,
                      child: Align(
                        child: SizedBox(
                          width: 297*fem,
                          height: 39*fem,
                          child: Text(
                            'Dagtar untuk membaca dan menulis cerita gratis!',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // membacadanmenulisceritadigenre (5:49)
              left: 39.5*fem,
              top: 711*fem,
              child: Align(
                child: SizedBox(
                  width: 352*fem,
                  height: 18*fem,
                  child: Text(
                    'Membaca dan menulis cerita di genre apa pun',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xeaafa0a0),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // punyaakunEbS (5:50)
              left: 130.5*fem,
              top: 862*fem,
              child: Align(
                child: SizedBox(
                  width: 106*fem,
                  height: 18*fem,
                  child: Text(
                    'Punya Akun? ',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xeaafa0a0),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // masuk7v8 (5:69)
              left: 241.5*fem,
              top: 862*fem,
              child: Align(
                child: SizedBox(
                  width: 52*fem,
                  height: 18*fem,
                  child: Text(
                    'Masuk',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle2dNg (5:51)
              left: 49*fem,
              top: 801*fem,
              child: Align(
                child: SizedBox(
                  width: 333*fem,
                  height: 41*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(50*fem),
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group3jAp (5:60)
              left: 49*fem,
              top: 346*fem,
              child: Container(
                width: 350*fem,
                height: 220*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // emailqUk (5:48)
                      left: 0*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 55*fem,
                          height: 23*fem,
                          child: Text(
                            'Email',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 19*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xadffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // rectangle10jq2 (5:59)
                      left: 4*fem,
                      top: 38*fem,
                      child: Align(
                        child: SizedBox(
                          width: 346*fem,
                          height: 1*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xaad1cfcf),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // namapenggunaSzL (5:61)
                      left: 0*fem,
                      top: 62*fem,
                      child: Align(
                        child: SizedBox(
                          width: 163*fem,
                          height: 23*fem,
                          child: Text(
                            'Nama Pengguna',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 19*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xadffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // rectangle11wAQ (5:62)
                      left: 4*fem,
                      top: 99*fem,
                      child: Align(
                        child: SizedBox(
                          width: 346*fem,
                          height: 1*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xaad1cfcf),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // katasandiFgt (5:63)
                      left: 0*fem,
                      top: 119*fem,
                      child: Align(
                        child: SizedBox(
                          width: 110*fem,
                          height: 23*fem,
                          child: Text(
                            'Kata Sandi',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 19*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xadffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tampilkan9nG (5:67)
                      left: 262*fem,
                      top: 120*fem,
                      child: Align(
                        child: SizedBox(
                          width: 80*fem,
                          height: 18*fem,
                          child: Text(
                            'Tampilkan',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 15*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xadffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // rectangle12fEp (5:64)
                      left: 4*fem,
                      top: 157*fem,
                      child: Align(
                        child: SizedBox(
                          width: 346*fem,
                          height: 1*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xaad1cfcf),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tanggallahirb8U (5:65)
                      left: 0*fem,
                      top: 181*fem,
                      child: Align(
                        child: SizedBox(
                          width: 127*fem,
                          height: 23*fem,
                          child: Text(
                            'Tanggal lahir',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 19*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xadffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // rectangle13JHn (5:66)
                      left: 4*fem,
                      top: 219*fem,
                      child: Align(
                        child: SizedBox(
                          width: 346*fem,
                          height: 1*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xaad1cfcf),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // daftardL4 (5:52)
              left: 184*fem,
              top: 810*fem,
              child: Align(
                child: SizedBox(
                  width: 54*fem,
                  height: 18*fem,
                  child: Text(
                    'Daftar',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // persyaratanlayanankebijakanpri (5:68)
              left: 59*fem,
              top: 767*fem,
              child: Align(
                child: SizedBox(
                  width: 304*fem,
                  height: 17*fem,
                  child: RichText(
                    text: TextSpan(
                      style: SafeGoogleFont (
                        'Goldman',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2*ffem/fem,
                        color: Color(0xffcd8dff),
                      ),
                      children: [
                        TextSpan(
                          text: 'Persyaratan Layanan ',
                        ),
                        TextSpan(
                          text: '&',
                          style: SafeGoogleFont (
                            'Goldman',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                        TextSpan(
                          text: ' Kebijakan Privasi',
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}