import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax5aGx (28:47)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xff000000),
        ),
        child: Stack(
          children: [
            Positioned(
              // jelajahitagartYY (28:135)
              left: 13*fem,
              top: 172*fem,
              child: Align(
                child: SizedBox(
                  width: 132*fem,
                  height: 22*fem,
                  child: Text(
                    'Jelajahi Tagar',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogrouptivoxoJ (QXBd5La4dPA5BehZ7UTivo)
              left: 12*fem,
              top: 205*fem,
              child: Container(
                width: 402*fem,
                height: 68*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // rectangle27VHS (28:136)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                      width: 192*fem,
                      height: 68*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                    Container(
                      // rectangle28pKi (28:138)
                      width: 192*fem,
                      height: 68*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupkohmN6L (QXBdGR5wNQys6ZRStqkohM)
              left: 12*fem,
              top: 285*fem,
              child: Container(
                width: 402*fem,
                height: 68*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // rectangle29tqN (28:139)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                      width: 192*fem,
                      height: 68*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                    Container(
                      // rectangle30EPS (28:140)
                      width: 192*fem,
                      height: 68*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffd9d9d9),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle15aTJ (28:77)
              left: 0*fem,
              top: 848*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 84*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0x75ffffff)),
                      color: Color(0xff302d2d),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle17oax (28:78)
              left: 134*fem,
              top: 918*fem,
              child: Align(
                child: SizedBox(
                  width: 161*fem,
                  height: 5*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // kisspngcomputericonshomeclipar (28:79)
              left: 32*fem,
              top: 868*fem,
              child: Align(
                child: SizedBox(
                  width: 33*fem,
                  height: 30*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/kisspng-computer-icons-home-clip-art-black-home-icon-5ab0be3121a1f5-1-7Y4.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // kisspngportablenetworkgraphics (28:80)
              left: 147*fem,
              top: 873*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 25*fem,
                  child: Image.asset(
                    'assets/page-1/images/kisspng-portable-network-graphics-computer-icons-clip-art-74-svg-together-icons-for-free-download-uihere-5d06e95fdfffb0-1.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle16RVr (28:81)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 152*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0x75ffffff)),
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle24L72 (28:90)
              left: 29*fem,
              top: 102*fem,
              child: Align(
                child: SizedBox(
                  width: 372*fem,
                  height: 31*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(100*fem),
                      border: Border.all(color: Color(0x4cffffff)),
                      color: Color(0xff2f2e2e),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // telusuriETJ (28:85)
              left: 13.5*fem,
              top: 49*fem,
              child: Align(
                child: SizedBox(
                  width: 93*fem,
                  height: 27*fem,
                  child: Text(
                    'Telusuri',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 22*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // telusuribukuatauprofilKUk (28:94)
              left: 74.5*fem,
              top: 109*fem,
              child: Align(
                child: SizedBox(
                  width: 189*fem,
                  height: 18*fem,
                  child: Text(
                    'Telusuri buku atau profil',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0x7fffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle3RXn (28:86)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 48*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // kisspngportablenetworkgraphics (28:93)
              left: 47*fem,
              top: 108*fem,
              child: Align(
                child: SizedBox(
                  width: 22*fem,
                  height: 20*fem,
                  child: Image.asset(
                    'assets/page-1/images/kisspng-portable-network-graphics-computer-icons-clip-art-74-svg-together-icons-for-free-download-uihere-5d06e95fdfffb0-2.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // pngwing1qLc (28:95)
              left: 255*fem,
              top: 870*fem,
              child: Align(
                child: SizedBox(
                  width: 32*fem,
                  height: 32*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/pngwing-1.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // lonceng1w8k (28:96)
              left: 359*fem,
              top: 869*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 34*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/lonceng-1.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}