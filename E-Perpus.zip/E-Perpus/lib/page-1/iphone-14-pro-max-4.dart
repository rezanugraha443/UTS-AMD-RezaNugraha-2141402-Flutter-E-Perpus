import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax4VRS (14:2)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xff000000),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupttxhzd6 (QXBbEe8r7Z4c8no7XTtTXh)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                width: 472*fem,
                height: 932*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // rectangle1gkp (14:4)
                      left: 42*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 430*fem,
                          height: 932*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // rectangle20CDN (28:28)
                      left: 0*fem,
                      top: 106*fem,
                      child: Align(
                        child: SizedBox(
                          width: 430*fem,
                          height: 257*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xba343232),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // rectangle21ihW (28:29)
                      left: 0*fem,
                      top: 548*fem,
                      child: Align(
                        child: SizedBox(
                          width: 430*fem,
                          height: 136*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xba343232),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bukuinisangatdiperlukansebagai (28:9)
                      left: 10*fem,
                      top: 130*fem,
                      child: Align(
                        child: SizedBox(
                          width: 359*fem,
                          height: 34*fem,
                          child: Text(
                            'Buku ini sangat diperlukan sebagai referensi bagi mahasiswa dan dosen.',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xb2ffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bukuinimerupakankumpulanbahana (28:27)
                      left: 11*fem,
                      top: 569*fem,
                      child: Align(
                        child: SizedBox(
                          width: 390*fem,
                          height: 68*fem,
                          child: Text(
                            'Buku ini merupakan kumpulan bahan ajar untuk mata kuliah dengan judul yang sama. Di dalam buku ini akan dibahas tentang pengertian sistem informasi dan penerapannya dalam ilmu kesehatan.',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xb2ffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // bukupilihanuntukkamuAbS (28:10)
                      left: 10*fem,
                      top: 368*fem,
                      child: Align(
                        child: SizedBox(
                          width: 220*fem,
                          height: 20*fem,
                          child: Text(
                            'Buku Pilihan untuk Kamu',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // rz4 (28:30)
                      left: 397*fem,
                      top: 547*fem,
                      child: Align(
                        child: SizedBox(
                          width: 18*fem,
                          height: 20*fem,
                          child: Text(
                            '...',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // konsepdasarsikesehatan9yA (28:26)
                      left: 11*fem,
                      top: 548*fem,
                      child: Align(
                        child: SizedBox(
                          width: 250*fem,
                          height: 20*fem,
                          child: Text(
                            'Konsep Dasar SI Kesehatan',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // metodepenelitianTU4 (28:37)
                      left: 157*fem,
                      top: 745*fem,
                      child: Align(
                        child: SizedBox(
                          width: 161*fem,
                          height: 20*fem,
                          child: Text(
                            'Metode Penelitian',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // detaillebihlanjut95z (28:32)
                      left: 259*fem,
                      top: 655*fem,
                      child: Align(
                        child: SizedBox(
                          width: 158*fem,
                          height: 17*fem,
                          child: Text(
                            'Detail Lebih Lanjut >',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // sisteminformasiqUc (28:17)
                      left: 11*fem,
                      top: 109*fem,
                      child: Align(
                        child: SizedBox(
                          width: 152*fem,
                          height: 20*fem,
                          child: Text(
                            'Sistem Informasi',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // image1LRN (28:12)
                      left: 14*fem,
                      top: 173*fem,
                      child: Align(
                        child: SizedBox(
                          width: 128*fem,
                          height: 183*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-1.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // image2ewr (28:16)
                      left: 157*fem,
                      top: 173*fem,
                      child: Align(
                        child: SizedBox(
                          width: 124*fem,
                          height: 184*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-2.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // group7yUL (28:31)
                      left: 17*fem,
                      top: 395*fem,
                      child: Container(
                        width: 401*fem,
                        height: 141*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // image35nG (28:19)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                              width: 90*fem,
                              height: 141*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-3.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                            Container(
                              // image4cvc (28:21)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                              width: 106*fem,
                              height: 141*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-4.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                            Container(
                              // image5M7W (28:23)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
                              width: 86*fem,
                              height: 141*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-5.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                            Container(
                              // image65ZJ (28:25)
                              width: 105*fem,
                              height: 141*fem,
                              child: Image.asset(
                                'assets/page-1/images/image-6.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // image7ESC (28:36)
                      left: 25*fem,
                      top: 707*fem,
                      child: Align(
                        child: SizedBox(
                          width: 122*fem,
                          height: 172*fem,
                          child: Image.asset(
                            'assets/page-1/images/image-7.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // kisspngcomputericonscomputerso (14:31)
                      left: 187*fem,
                      top: 781*fem,
                      child: Align(
                        child: SizedBox(
                          width: 25*fem,
                          height: 23*fem,
                          child: Image.asset(
                            'assets/page-1/images/kisspng-computer-icons-computer-software-download-slider-5ade9eecdffe75-1.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // rectangle22T44 (28:38)
                      left: 259*fem,
                      top: 785*fem,
                      child: Align(
                        child: SizedBox(
                          width: 61*fem,
                          height: 15*fem,
                          child: Image.asset(
                            'assets/page-1/images/rectangle-22.png',
                            width: 61*fem,
                            height: 15*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // lengkapAUG (28:41)
                      left: 266*fem,
                      top: 786*fem,
                      child: Align(
                        child: SizedBox(
                          width: 49*fem,
                          height: 12*fem,
                          child: Text(
                            'Lengkap',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 10*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // hals7n (28:42)
                      left: 215*fem,
                      top: 786*fem,
                      child: Align(
                        child: SizedBox(
                          width: 36*fem,
                          height: 12*fem,
                          child: Text(
                            '30 Hal',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 10*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // rectangle23ZWQ (28:43)
                      left: 174*fem,
                      top: 825*fem,
                      child: Align(
                        child: SizedBox(
                          width: 147*fem,
                          height: 24*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(100*fem),
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // pratinjaurkQ (28:44)
                      left: 205*fem,
                      top: 827*fem,
                      child: Align(
                        child: SizedBox(
                          width: 83*fem,
                          height: 20*fem,
                          child: Text(
                            'Pratinjau',
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // bukudenganjudulmetodepenelitia (28:45)
              left: 27*fem,
              top: 885*fem,
              child: Align(
                child: SizedBox(
                  width: 368*fem,
                  height: 84*fem,
                  child: Text(
                    'Buku dengan judul “METODE PENELITIAN TEKNIK INFORMATIKA” ini, alhamdulillah telah selesai kami susun. Dengan mengetengahkan tentang metode penelitian menurut Islam dan beberapa identifikasi masalah seputar Teknik Informatika.',
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xb2ffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // detaillebihlanjutjhi (28:46)
              left: 129*fem,
              top: 997*fem,
              child: Align(
                child: SizedBox(
                  width: 158*fem,
                  height: 17*fem,
                  child: Text(
                    'Detail Lebih Lanjut >',
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group42Rv (18:2)
              left: 0*fem,
              top: 848*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(134*fem, 70*fem, 135*fem, 9*fem),
                width: 430*fem,
                height: 84*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0x75ffffff)),
                  color: Color(0xff302d2d),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Align(
                  // rectangle17V4c (14:36)
                  alignment: Alignment.bottomCenter,
                  child: SizedBox(
                    width: double.infinity,
                    height: 5*fem,
                    child: Container(
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(5*fem),
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // kisspngcomputericonshomeclipar (14:29)
              left: 32*fem,
              top: 868*fem,
              child: Align(
                child: SizedBox(
                  width: 33*fem,
                  height: 30*fem,
                  child: Image.asset(
                    'assets/page-1/images/kisspng-computer-icons-home-clip-art-black-home-icon-5ab0be3121a1f5-1-xmn.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // kisspngportablenetworkgraphics (14:30)
              left: 139*fem,
              top: 873*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 25*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/kisspng-portable-network-graphics-computer-icons-clip-art-74-svg-together-icons-for-free-download-uihere-5d06e95fdfffb0-1-XF6.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle169oN (14:33)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 97*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0x75ffffff)),
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group5f12 (18:3)
              left: 10.5*fem,
              top: 54*fem,
              child: Container(
                width: 414.5*fem,
                height: 37*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // halamanutamaaNt (14:7)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 182.5*fem, 4*fem),
                      child: Text(
                        'Halaman Utama',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Goldman',
                          fontSize: 19*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                    Container(
                      // kisspngcomputericonscomputerso (28:40)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 1*fem),
                      width: 26*fem,
                      height: 26*fem,
                      child: Image.asset(
                        'assets/page-1/images/kisspng-computer-icons-computer-software-download-slider-5ade9eecdffe75-2.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // ellipse1zBi (14:32)
                      width: 37*fem,
                      height: 37*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(18.5*fem),
                        border: Border.all(color: Color(0xffffffff)),
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/ellipse-1-bg-f5J.png',
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle3Wfr (14:24)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 48*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pngwing12u6 (28:99)
              left: 255*fem,
              top: 870*fem,
              child: Align(
                child: SizedBox(
                  width: 32*fem,
                  height: 32*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/pngwing-1-G9e.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // lonceng1x24 (28:100)
              left: 359*fem,
              top: 869*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 34*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/lonceng-1-Jtx.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}