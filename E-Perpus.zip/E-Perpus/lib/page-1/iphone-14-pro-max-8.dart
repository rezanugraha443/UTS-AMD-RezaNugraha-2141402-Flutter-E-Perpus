import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax8GHv (35:169)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xff000000),
        ),
        child: Stack(
          children: [
            Positioned(
              // kirimpesanpribadikeprofilyangt (35:170)
              left: 43*fem,
              top: 196*fem,
              child: Align(
                child: SizedBox(
                  width: 324*fem,
                  height: 53*fem,
                  child: Text(
                    'Kirim pesan pribadi ke profil yang terhubung denganmu',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 22*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xff4197fb),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // bagikanceritayangkamusukaideng (35:171)
              left: 69*fem,
              top: 265*fem,
              child: Align(
                child: SizedBox(
                  width: 292*fem,
                  height: 27*fem,
                  child: Text(
                    'Bagikan cerita yang kamu sukai dengan teman, dan kirimkan pujian kepada penulis yang kamu sukai',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 11*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xff929393),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle3358t (36:192)
              left: 138*fem,
              top: 333*fem,
              child: Align(
                child: SizedBox(
                  width: 141*fem,
                  height: 36*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff2d74fd),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle15Bxc (35:172)
              left: 0*fem,
              top: 848*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 84*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0x75ffffff)),
                      color: Color(0xff302d2d),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle17Uwi (35:173)
              left: 134*fem,
              top: 918*fem,
              child: Align(
                child: SizedBox(
                  width: 161*fem,
                  height: 5*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // kisspngcomputericonshomeclipar (35:174)
              left: 32*fem,
              top: 868*fem,
              child: Align(
                child: SizedBox(
                  width: 33*fem,
                  height: 30*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/kisspng-computer-icons-home-clip-art-black-home-icon-5ab0be3121a1f5-1-EQG.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // kisspngportablenetworkgraphics (35:175)
              left: 147*fem,
              top: 873*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 25*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/kisspng-portable-network-graphics-computer-icons-clip-art-74-svg-together-icons-for-free-download-uihere-5d06e95fdfffb0-1-n7J.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle16vhE (35:176)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 132*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0x75ffffff)),
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pembaharuanFDi (35:177)
              left: 18*fem,
              top: 42*fem,
              child: Align(
                child: SizedBox(
                  width: 162*fem,
                  height: 27*fem,
                  child: Text(
                    'Pembaharuan',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 22*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pesanbaruXh2 (36:193)
              left: 155.5*fem,
              top: 341*fem,
              child: Align(
                child: SizedBox(
                  width: 105*fem,
                  height: 18*fem,
                  child: Text(
                    '+ Pesan Baru',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle3dEG (35:178)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 48*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pngwing1m5a (35:179)
              left: 255*fem,
              top: 870*fem,
              child: Align(
                child: SizedBox(
                  width: 32*fem,
                  height: 32*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/pngwing-1-FYt.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // lonceng14aU (35:180)
              left: 359*fem,
              top: 869*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 34*fem,
                  child: Image.asset(
                    'assets/page-1/images/lonceng-1-47a.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle32o2G (35:181)
              left: 28*fem,
              top: 83*fem,
              child: Align(
                child: SizedBox(
                  width: 361*fem,
                  height: 24*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xffa5a5a5),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle31ub6 (35:182)
              left: 28*fem,
              top: 83*fem,
              child: Align(
                child: SizedBox(
                  width: 177*fem,
                  height: 24*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(5*fem),
                        color: Color(0xdd464646),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // notifikasiR3e (35:183)
              left: 84*fem,
              top: 87*fem,
              child: Align(
                child: SizedBox(
                  width: 72*fem,
                  height: 17*fem,
                  child: Text(
                    'Notifikasi',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pesanXcU (35:184)
              left: 280.5*fem,
              top: 87*fem,
              child: Align(
                child: SizedBox(
                  width: 47*fem,
                  height: 17*fem,
                  child: Text(
                    'Pesan',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}