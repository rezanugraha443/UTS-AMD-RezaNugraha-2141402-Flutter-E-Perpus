import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax7p5v (28:141)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xff000000),
        ),
        child: Stack(
          children: [
            Positioned(
              // tidakadanotifikasiuntuksaatini (28:167)
              left: 57*fem,
              top: 196*fem,
              child: Align(
                child: SizedBox(
                  width: 296*fem,
                  height: 53*fem,
                  child: Text(
                    'Tidak ada notifikasi untuk saat ini.',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 22*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xff4197fb),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pembaharuandaribukuceritadiper (28:168)
              left: 68*fem,
              top: 265*fem,
              child: Align(
                child: SizedBox(
                  width: 294*fem,
                  height: 27*fem,
                  child: Text(
                    'Pembaharuan dari buku/cerita diperpustakaan dan profil yang kamu ikuti akan muncul disini',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 11*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xff929393),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle15g1e (28:152)
              left: 0*fem,
              top: 848*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 84*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0x75ffffff)),
                      color: Color(0xff302d2d),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle179vp (28:153)
              left: 134*fem,
              top: 918*fem,
              child: Align(
                child: SizedBox(
                  width: 161*fem,
                  height: 5*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // kisspngcomputericonshomeclipar (28:154)
              left: 32*fem,
              top: 868*fem,
              child: Align(
                child: SizedBox(
                  width: 33*fem,
                  height: 30*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/kisspng-computer-icons-home-clip-art-black-home-icon-5ab0be3121a1f5-1.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // kisspngportablenetworkgraphics (28:155)
              left: 147*fem,
              top: 873*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 25*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/kisspng-portable-network-graphics-computer-icons-clip-art-74-svg-together-icons-for-free-download-uihere-5d06e95fdfffb0-1-LpG.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle16pQg (28:156)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 132*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0x75ffffff)),
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pembaharuanj1r (28:157)
              left: 18*fem,
              top: 42*fem,
              child: Align(
                child: SizedBox(
                  width: 162*fem,
                  height: 27*fem,
                  child: Text(
                    'Pembaharuan',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 22*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle31zx (28:159)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 48*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pngwing1w7v (28:160)
              left: 255*fem,
              top: 870*fem,
              child: Align(
                child: SizedBox(
                  width: 32*fem,
                  height: 32*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/pngwing-1-VF6.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // lonceng1rEt (28:161)
              left: 359*fem,
              top: 869*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 34*fem,
                  child: Image.asset(
                    'assets/page-1/images/lonceng-1-dfe.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle32yaQ (28:164)
              left: 28*fem,
              top: 83*fem,
              child: Align(
                child: SizedBox(
                  width: 361*fem,
                  height: 24*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(5*fem),
                        color: Color(0xff4d4c4c),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle31Syn (28:163)
              left: 28*fem,
              top: 83*fem,
              child: Align(
                child: SizedBox(
                  width: 177*fem,
                  height: 24*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xdd9b9797),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // notifikasimFN (28:165)
              left: 84*fem,
              top: 87*fem,
              child: Align(
                child: SizedBox(
                  width: 72*fem,
                  height: 17*fem,
                  child: Text(
                    'Notifikasi',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pesanfLk (28:166)
              left: 280.5*fem,
              top: 87*fem,
              child: Align(
                child: SizedBox(
                  width: 47*fem,
                  height: 17*fem,
                  child: Text(
                    'Pesan',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}