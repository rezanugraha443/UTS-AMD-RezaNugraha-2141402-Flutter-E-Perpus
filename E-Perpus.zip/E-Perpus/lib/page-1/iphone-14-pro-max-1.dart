import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // iphone14promax1kgQ (1:2)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          padding: EdgeInsets.fromLTRB(44*fem, 420*fem, 79*fem, 452*fem),
          width: double.infinity,
          height: 932*fem,
          decoration: BoxDecoration (
            color: Color(0xffffffff),
          ),
          child: Container(
            // group67on (28:8)
            width: double.infinity,
            height: double.infinity,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  // logoremovebgpreview13hS (28:7)
                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 5*fem),
                  width: 50*fem,
                  height: 45*fem,
                  child: Image.asset(
                    'assets/page-1/images/logo-removebg-preview-1-n2L.png',
                    fit: BoxFit.cover,
                  ),
                ),
                Text(
                  // eperpuswXv (3:5)
                  'E-Perpus',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont (
                    'Goldman',
                    fontSize: 50*ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.2*ffem/fem,
                    color: Color(0xff4d8dec),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
          );
  }
}