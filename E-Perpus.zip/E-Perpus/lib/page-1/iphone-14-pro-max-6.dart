import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax6EmN (28:101)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xff000000),
        ),
        child: Stack(
          children: [
            Positioned(
              // group8XkU (28:125)
              left: 0*fem,
              top: 101*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(65*fem, 9*fem, 156.5*fem, 8*fem),
                width: 485*fem,
                height: 60*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffffffff)),
                  color: Color(0xff000000),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // rectangle25ohz (28:121)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.5*fem, 0*fem),
                      width: 42*fem,
                      height: 43*fem,
                      child: Image.asset(
                        'assets/page-1/images/rectangle-25.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // buatceritabukubaru8EU (28:123)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 0*fem, 0*fem),
                      child: Text(
                        'Buat Cerita/Buku baru',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Goldman',
                          fontSize: 18*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group9RDa (28:126)
              left: 0*fem,
              top: 154*fem,
              child: Container(
                width: 485*fem,
                height: 46*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffffffff)),
                  color: Color(0xff3a5edb),
                ),
                child: Center(
                  child: Text(
                    'Sumber bermanfaat bagi penulis',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group10tN4 (28:132)
              left: 0*fem,
              top: 196*fem,
              child: Container(
                width: 485*fem,
                height: 46*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xffffffff)),
                  color: Color(0xff3a5edb),
                ),
                child: Center(
                  child: Text(
                    'E-Perpus Stmik AmikBandung',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle15mAx (28:102)
              left: 0*fem,
              top: 848*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 84*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0x75ffffff)),
                      color: Color(0xff302d2d),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle174Qx (28:103)
              left: 134*fem,
              top: 918*fem,
              child: Align(
                child: SizedBox(
                  width: 161*fem,
                  height: 5*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // kisspngcomputericonshomeclipar (28:104)
              left: 32*fem,
              top: 868*fem,
              child: Align(
                child: SizedBox(
                  width: 33*fem,
                  height: 30*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/kisspng-computer-icons-home-clip-art-black-home-icon-5ab0be3121a1f5-1-JpG.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // kisspngportablenetworkgraphics (28:105)
              left: 147*fem,
              top: 873*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 25*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/kisspng-portable-network-graphics-computer-icons-clip-art-74-svg-together-icons-for-free-download-uihere-5d06e95fdfffb0-1-baG.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle16fZA (28:106)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 99*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0x75ffffff)),
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // tulisNyN (28:108)
              left: 31.5*fem,
              top: 44*fem,
              child: Align(
                child: SizedBox(
                  width: 55*fem,
                  height: 27*fem,
                  child: Text(
                    'Tulis',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 22*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rezanugrahatB2 (28:115)
              left: 245.5*fem,
              top: 48*fem,
              child: Align(
                child: SizedBox(
                  width: 123*fem,
                  height: 18*fem,
                  child: Text(
                    '@RezaNugraha',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle3Znx (28:110)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 48*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pngwing1tKS (28:112)
              left: 255*fem,
              top: 870*fem,
              child: Align(
                child: SizedBox(
                  width: 32*fem,
                  height: 32*fem,
                  child: Image.asset(
                    'assets/page-1/images/pngwing-1-Kzx.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // lonceng1oSQ (28:113)
              left: 359*fem,
              top: 869*fem,
              child: Align(
                child: SizedBox(
                  width: 27*fem,
                  height: 34*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Image.asset(
                      'assets/page-1/images/lonceng-1-9uS.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse1K9r (28:114)
              left: 372*fem,
              top: 40*fem,
              child: Align(
                child: SizedBox(
                  width: 37*fem,
                  height: 37*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(18.5*fem),
                      border: Border.all(color: Color(0xffffffff)),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-1-bg.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}