import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // iphone14promax2eUG (5:3)
        width: double.infinity,
        height: 932*fem,
        decoration: BoxDecoration (
          color: Color(0xff000000),
        ),
        child: Stack(
          children: [
            Positioned(
              // group29fv (5:36)
              left: 0*fem,
              top: 287*fem,
              child: Container(
                width: 816*fem,
                height: 206*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // rectangle4raL (5:26)
                      margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 20*fem, 0*fem),
                      width: 390*fem,
                      height: 203*fem,
                      child: Image.asset(
                        'assets/page-1/images/rectangle-4.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // rectangle6aWL (5:30)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 1*fem),
                      width: 126*fem,
                      height: 205*fem,
                      child: Image.asset(
                        'assets/page-1/images/rectangle-6.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // rectangle7gpG (5:31)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 1*fem),
                      width: 125*fem,
                      height: 205*fem,
                      child: Image.asset(
                        'assets/page-1/images/rectangle-7.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // rectangle91Lk (5:35)
                      margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 0*fem),
                      width: 128*fem,
                      height: 204*fem,
                      child: Image.asset(
                        'assets/page-1/images/rectangle-9.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle19Y5n (14:38)
              left: 135*fem,
              top: 920*fem,
              child: Align(
                child: SizedBox(
                  width: 161*fem,
                  height: 5*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(5*fem),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group1dsv (5:34)
              left: 57*fem,
              top: 85*fem,
              child: Container(
                width: 305*fem,
                height: 77*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // eperpuskxY (5:5)
                      left: 51*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 254*fem,
                          height: 60*fem,
                          child: Text(
                            'E-Perpus',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 50*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xff4d8dec),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // logoremovebgpreview1qj6 (28:2)
                      left: 0*fem,
                      top: 4*fem,
                      child: Align(
                        child: SizedBox(
                          width: 50*fem,
                          height: 45*fem,
                          child: Image.asset(
                            'assets/page-1/images/logo-removebg-preview-1.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // tempatceritamenjadihidup9jn (5:7)
                      left: 41*fem,
                      top: 57*fem,
                      child: Align(
                        child: SizedBox(
                          width: 234*fem,
                          height: 20*fem,
                          child: Text(
                            'Tempat cerita menjadi hidup',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Goldman',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // keberagamanceritayangakankamus (5:8)
              left: 58.5*fem,
              top: 642*fem,
              child: Align(
                child: SizedBox(
                  width: 313*fem,
                  height: 56*fem,
                  child: Text(
                    'Keberagaman cerita yang akan kamu sukai',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 23*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // membacadanmenulisceritadigenre (5:9)
              left: 39.5*fem,
              top: 711*fem,
              child: Align(
                child: SizedBox(
                  width: 352*fem,
                  height: 18*fem,
                  child: Text(
                    'Membaca dan menulis cerita di genre apa pun',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xeaafa0a0),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // jikakamumemilikisebuahakunmasu (5:13)
              left: 64.5*fem,
              top: 875*fem,
              child: Align(
                child: SizedBox(
                  width: 302*fem,
                  height: 18*fem,
                  child: Text(
                    'Jika kamu memiliki sebuah akun Masuk',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xeaafa0a0),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle23s6 (5:11)
              left: 49*fem,
              top: 801*fem,
              child: Align(
                child: SizedBox(
                  width: 333*fem,
                  height: 41*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(50*fem),
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // bergabunglahsecaragratisXXN (5:12)
              left: 101.5*fem,
              top: 810*fem,
              child: Align(
                child: SizedBox(
                  width: 219*fem,
                  height: 18*fem,
                  child: Text(
                    'Bergabunglah secara gratis',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Goldman',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle3Df6 (5:22)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 430*fem,
                  height: 67*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}